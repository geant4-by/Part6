#include "MyRun.hh"

MyRun::MyRun():G4Run () {Total_dE=0;}
MyRun::~MyRun() {}

void MyRun::Add_totalE(G4double e)
{
 Total_dE+=e;
}

G4double MyRun::Get_totalE()
{
 return Total_dE;
}

void MyRun::Merge(const G4Run* aRun)
{
 const MyRun* localRun = static_cast<const MyRun*>(aRun);
 Total_dE += localRun->Total_dE;
 G4Run::Merge(aRun);
}
