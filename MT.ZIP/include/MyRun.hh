//#pragma once

#ifndef MyRun_hh
#define MyRun_hh

#include <G4Run.hh>

class MyRun : public G4Run 
{
 public:
  MyRun();
  ~MyRun() override;
  void Add_totalE(G4double e);
  G4double Get_totalE();
  void Merge(const G4Run*) override;
 private:
  G4double Total_dE;
};

#endif
