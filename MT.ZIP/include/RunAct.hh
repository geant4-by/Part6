//#pragma once

#ifndef RunAct_hh
#define RunAct_hh

#include <G4UserRunAction.hh>
#include <G4Run.hh>
#include <G4Threading.hh>
#include <G4AutoLock.hh>
#include "globals.hh"
#include "MyRun.hh"
#include <ctime>
#include <fstream>

class RunAct : public G4UserRunAction {
public:
	RunAct(std::ofstream& ofsa);
	 ~RunAct();
	std::ofstream *f_act;

        G4Run* GenerateRun() override;
        void Add_totalE(G4double e);
	void BeginOfRunAction(const G4Run*);
	void EndOfRunAction(const G4Run*);
        MyRun* fMyRun;	
 static void AddE_total(G4double dE);
};

#endif
