#ifndef FINAL_LOADER_HH
#define FINAL_LOADER_HH

#include <G4GlobalConfig.hh>	
#ifdef G4MULTITHREADED
 #include <G4MTRunManager.hh>
#else
 #include <G4RunManager.hh>
#endif
#include <G4StepLimiter.hh>
#include <G4UserLimits.hh>
#include <G4UImanager.hh>
#include <G4VisManager.hh>
#include <G4ParallelWorldPhysics.hh>
#include <G4ParallelWorldScoringProcess.hh>
#include <G4PhysicsListHelper.hh>
#include <G4ParticleTable.hh>
#include <G4UImanager.hh>
#include <QBBC.hh>
#include <G4StepLimiterPhysics.hh>

#include <iostream>
#include <iomanip>
#include <stdio.h>

#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"

class Loader
{
 private:
  std::ofstream *ofs_sn;

#ifdef G4MULTITHREADED
  G4MTRunManager* runManager;
#else
  G4RunManager* runManager;
#endif

   G4VisManager* visManager;
public:
    Loader(int argc, char** argv, std::ofstream& fout);
    ~Loader();
};

#endif //FINAL_LOADER_HH
